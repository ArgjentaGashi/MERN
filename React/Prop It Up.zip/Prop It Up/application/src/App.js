import logo from './logo.svg';
import './App.css';

const PersonCard = (props) => {
    const {firstName, lastName, age, hairColor} = props;
    return ( 
      <>
      <h2> {lastName}, {firstName} </h2>
      <p>Age: {age}</p>
      <p>Hair Color: {hairColor}</p>
      </>
    );
  };

function App() {
  return (
    <div className="App">
      <PersonCard firstName={"Jane"} lastName={"Doe"} age={45} hairColor="Black" />
      <PersonCard firstName={"John"} lastName={"Smith"} age={88} hairColor="Brown" />
      <PersonCard firstName={"Millard"} lastName={"Fillmore"} age={50} hairColor="Brown" />
      <PersonCard firstName={"Maria"} lastName={"Smith"} age={62} hairColor="Brown" />
    </div>
  );
}

export default App;
